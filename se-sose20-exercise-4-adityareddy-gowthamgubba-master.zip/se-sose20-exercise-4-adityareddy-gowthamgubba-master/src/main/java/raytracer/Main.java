package raytracer;

public class Main {
    public static void main(String [] args) throws Exception {
        // resources
        final String file = "./resources/scene.x3d";
        final String image = "./out/image.png";


        // specifying image width and height in pixels
        final int imageWidth = 800;
        final int imageHeight = 800;


        // setting up the view frustum (view area for tracing objects)
        float viewDistance = 1.0f;
        Vec3D origin = new Vec3D(0, 0, 0);
        Vec3D viewDirection = new Vec3D(0, 0, 1);
        Camera camera = new Camera(viewDistance, viewDirection, origin);
        ImagePlane imagePlane = new ImagePlane(imageWidth, imageHeight, camera);


        // ray tracing
        X3D x3d = new X3D(file);
        for (Shape shape : x3d.shapes){
            //System.out.println(shape); <------uncomment to see shapes being traced
            imagePlane.trace(shape);
        }

        // IO Operations
        imagePlane.removeImageFile(image);
        imagePlane.createImageFile(image);
    }
}
