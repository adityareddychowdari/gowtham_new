package raytracer;

public enum Elements {
    Transform("Transform"),
    Sphere("Sphere"),
    Cone("Cone");

    private final String text;

    Elements(final String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return text;
    }
}
