package raytracer;

public class Shape {

    public Geometry geometry;
    public Appearance appearance;

    /**
     * Constructs a Shape.
     * @param geometry
     *          The geometry based on .x3d specification.
     * @param appearance
     *          The appearance based on .x3d specification.
     */
    public Shape(Geometry geometry, Appearance appearance) {
        this.geometry = geometry;
        this.appearance = appearance;
    }

    @Override
    public String toString() {
        //todo add appearance
        return this.geometry.parameters();
    }
}

