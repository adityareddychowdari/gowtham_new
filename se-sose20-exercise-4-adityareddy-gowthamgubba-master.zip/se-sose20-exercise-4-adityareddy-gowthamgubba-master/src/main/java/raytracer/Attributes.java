package raytracer;

public enum Attributes {
    scale("scale"),
    radius("radius"),
    center("center"),
    rotation("rotation"),
    translation("translation"),
    diffuseColor("diffuseColor");

    private final String text;

    Attributes(final String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return text;
    }
}
