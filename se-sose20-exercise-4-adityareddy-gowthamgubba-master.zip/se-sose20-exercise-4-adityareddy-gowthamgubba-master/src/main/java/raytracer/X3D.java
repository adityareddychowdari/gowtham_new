package raytracer;

import javax.xml.stream.XMLStreamException;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class X3D {

    Scene scene;
    X3DParser parser;
    List<Shape> shapes = new ArrayList<>();

    /**
     * Constructs an X3D object using the X3DParser.
     *
     * @param file
     *          The file path of the .x3d file on the sys.
     */
    public X3D(String file) throws FileNotFoundException, XMLStreamException {
        this.parser = new X3DParser(file);
        this.parser.parse();
        this.scene = this.parser.getScene();
        this.shapes = this.scene.getShape();
    }
}
