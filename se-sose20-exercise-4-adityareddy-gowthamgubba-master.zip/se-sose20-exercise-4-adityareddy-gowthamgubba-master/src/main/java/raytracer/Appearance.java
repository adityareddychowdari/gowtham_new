package raytracer;

public class Appearance {

     Material material;

    /**
     * Constructs the appearance of a shape.
     * @param material
     *          The material of the shape.
     */
    public Appearance(Material material) {
        this.material = material;
    }
}
