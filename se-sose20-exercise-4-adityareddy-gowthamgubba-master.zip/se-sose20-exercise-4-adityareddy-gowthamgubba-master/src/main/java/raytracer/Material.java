package raytracer;

import java.awt.*;

public class Material {

    private Color diffuseColor;

    /**
     * Constructs Material.
     * @param diffuseColor
     *          Color of the material.
     */
    public Material(Color diffuseColor){
        this.diffuseColor = diffuseColor;
    }

    Color getDiffuseColor() {
        return diffuseColor;
    }
}

