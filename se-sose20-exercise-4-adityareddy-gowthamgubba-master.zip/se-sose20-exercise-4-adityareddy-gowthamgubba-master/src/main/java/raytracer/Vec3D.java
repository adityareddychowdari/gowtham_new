package raytracer;

public class Vec3D {

    private final double x, y, z;

    /**
     * Constructs a Vec3D
     * @param x
     *        The x coordinate.
     * @param y
     *        The y coordinate.
     * @param z
     *        The z coordinate.
     */
    public Vec3D(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public String toString() {
        return "[ " + x + ", " + y + ", " + z + " ]";
    }

    /**
     * Addition between 3D vectors
     */
    public Vec3D add(Vec3D other) {
        return new Vec3D(x + other.x, y + other.y, z + other.z);
    }

    /**
     * subtraction between 3D vectors
     */
    public Vec3D sub(Vec3D other) {
        return new Vec3D(x - other.x, y - other.y, z - other.z);
    }

    /**
     * scalar multiplication between 3D vectors
     */
    public Vec3D mul(double other) {
        return new Vec3D(x * other, y * other, z * other);
    }

    /**
     * dot product between 3D vectors
     */
    public double dot(Vec3D other) {
        return x * other.x + y * other.y + z * other.z;
    }

    /**
     * 3D vector magnitude (L2 norm)
     */
    public double len() {
        return Math.sqrt((x * x) + (y * y) + (z * z));
    }

    /**
     * cross product between 3D vectors
     */
    public Vec3D cross(Vec3D other) {
        double xDeterminant = (y * other.z) - (z * other.y);
        double yDeterminant = - ((x * other.z) - (z * other.x));
        double zDeterminant = (x * other.y) - (y * other.x);
        return new Vec3D(xDeterminant, yDeterminant, zDeterminant);
    }

    /**
     * Normalizing a vector
     */
    public Vec3D normalize() {
        return this.mul(1.0f / this.len());
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getZ() {
        return z;
    }
}
