package raytracer;

public class Sphere extends Geometry{

    private final Vec3D center;
    private final double radius;

    /**
     * Constructs a Sphere.
     * @param center
     *          The mid-position of the sphere.
     * @param radius
     *          The radius of the sphere.
     */
    public Sphere(Vec3D center, double radius) {
        this.center = center;
        this.radius = radius;
    }

    @Override
    String parameters() {
        return "Sphere\ncenter: " + center.toString() + "\nradius: " + radius + "\n";
    }

    /**
     * Evaluates ray-sphere intersection returning true if an
     * intersection exists. If otherwise, a false is returned.
     * @param ray
     *           The projected ray in a given direction.
     *
     * @see "http://viclw17.github.io/2018/07/16/raytracing-ray-sphere-intersection/"
     */
    @Override
    boolean intersect(Ray ray) {

        double r = this.radius;
        Vec3D  d = ray.getDirection();
        Vec3D oc = ray.getOrigin().sub(this.center);

        double a = d.dot(d);
        double b = 2.0 * (oc.dot(d));
        double c = oc.dot(oc) - (r * r);
        Function function = new Function(a, b, c);

        /* case 1: the ray does not intersect the sphere */
        if (function.getDiscriminant() < 0) {
            return false;
        }

        /* case 2: the ray touches the sphere at a single point */
        else if (function.getDiscriminant() == 0) {
            return true;
        }

        /* case 3: the ray touches the sphere two points  */
        else
            return true;
    }
}

