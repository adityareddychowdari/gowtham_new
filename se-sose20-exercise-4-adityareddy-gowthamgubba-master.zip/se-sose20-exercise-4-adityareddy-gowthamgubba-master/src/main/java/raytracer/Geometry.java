package raytracer;

public abstract class Geometry {
    abstract String parameters();
    abstract boolean intersect(Ray ray);
}
