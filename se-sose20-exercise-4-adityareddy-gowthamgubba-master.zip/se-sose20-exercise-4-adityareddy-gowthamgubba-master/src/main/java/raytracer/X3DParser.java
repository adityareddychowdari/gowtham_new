package raytracer;

import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import java.util.*;

public class X3DParser extends XMLParser {
    private int transform_nestLevel = 0;
    private final Scene scene = new Scene();

    public X3DParser(String filePath) {
        super(filePath);
    }


    @Override
    public void enter(StartElement element) {
        // readElement is a helper function for reading elements (see below)
        readElement(element, transform_nestLevel);

        // ... for each Transform element we encounter, lets track the nesting level
        if(element.getName().toString().equals("Transform")){
            transform_nestLevel = transform_nestLevel + 1;
        }
    }


    @Override
    public void exit(EndElement element) {
        // ... for each Transform element we encounter, lets track the nesting level
        if(element.getName().toString().equals("Transform")){
            transform_nestLevel = transform_nestLevel - 1;
        }
    }


    /**
     * Gets a final scene.
     */
    public Scene getScene(){
        return this.scene;
    }


    /**
     * Constructs a camera.
     *
     * @param element
     *          The opening tag element (or starting element tag).
     * @param transform_nestLevel
     *          The testing level of the current Element
     */
    private void readElement(StartElement element, int transform_nestLevel){
        // string var for element names
        String elementName;

        // navigable container for element attributes (String) and their values (String)
        NavigableMap<String, String> parsedAttribute = new TreeMap<String, String>(new Comparator<String>() {
            public int compare(final String o1, final String o2) {
                int result;
                if("Not-Specified".equals(o1)) {
                    result=1;
                } else if("Not-Specified".equals(o2)) {
                    result=-1;
                } else {
                    result =o1.compareTo(o2);
                }
                return result;
            }
        });

        // list for all element attributes
        List<Map<String, String>> elementAttributes = new ArrayList<>();

        // n.b. we only care about elements we defined in Elements (String Enumeration)
        for (Elements useElement : Elements.values()) {

            // for each relevant element ...
            if (element.getName().toString().equals(useElement.toString())) {
                elementName = element.getName().toString();

                // ... read the Element attribute/s
                Iterator<Attribute> iterator = element.getAttributes();
                while (iterator.hasNext()) {
                    Attribute attribute = iterator.next();

                    // n.b. we only care about element attributes we defined in Attributes (String Enumeration)
                    for(Attributes useAttribute : Attributes.values()){
                        if (attribute.getName().getLocalPart().equals(useAttribute.toString())) {

                            // lets add each parsed attribute into our navigable map
                            parsedAttribute.put(attribute.getName().getLocalPart(), attribute.getValue());

                            // before adding each parsed attribute to our list of parsed attributes
                            // ... lets check if the list is empty (so dont check the last entry)
                            if(elementAttributes.isEmpty()) {
                                elementAttributes.add(parsedAttribute);
                            }
                            // if our list is not empty
                            // ... lets check the last list-entry
                            else {
                                Map<String, String> lastEntry = elementAttributes.get(elementAttributes.size() - 1);

                                // ... and make sure the current entry is not a duplication
                                if(lastEntry != parsedAttribute){
                                    elementAttributes.add(parsedAttribute);
                                }
                            }
                        }
                    }
                }
                // finally, with [transform_nestLevel, elementName, and elementAttribute]
                // lets create our parsed element
                ParsedElement parsedElement = new ParsedElement(transform_nestLevel, elementName, elementAttributes);
                this.scene.addElement(parsedElement);
            }
        }
    }
}
