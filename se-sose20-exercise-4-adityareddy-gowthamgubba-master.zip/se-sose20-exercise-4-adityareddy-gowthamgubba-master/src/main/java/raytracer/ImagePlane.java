package raytracer;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

class ImagePlane{

    private final int width;
    private final int height;
    private final BufferedImage imagePlane;
    private final Camera camera;

    private final Vec3D imagePlanePos1;   // top left corner position of the view frame
    private final Vec3D imagePlanePos2;   // top right corner position of the view frame
    private final Vec3D imagePlanePos3;   // bottom left corner position of the view frame

    ImagePlane(int width, int height, Camera camera){
        this.width = width;
        this.height = height;
        this.camera = camera;

        // mid point of the view frame
        Vec3D frameMidPosition =
                camera.getCameraPosition().
                        add(camera.getViewDirection().
                                mul(camera.getViewDistance()));

        // creating the image plane and mapping its coordinate positions
        this.imagePlane = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        this.imagePlanePos1 = frameMidPosition.add(new Vec3D(-1, 1, 0));
        this.imagePlanePos2 = frameMidPosition.add(new Vec3D(1, 1, 0));
        this.imagePlanePos3 = frameMidPosition.add(new Vec3D(-1, -1, 0));
    }


    /**
     * Traces a shape within view onto the frame.
     *
     * @param shape
     *          A given shape.
     */
    public void trace(Shape shape){
        // for each pixel ...
        for(int y = 0; y < this.height; ++ y){
            for(int x = 0; x < this.width; ++ x){

                float widthProportion = (float)x / this.width;
                float heightProportion = (float)y / this.height;

                // pixel Vec3 position = framePosition1 + new_x_position + new_y_position
                Vec3D pixel  =
                        this.imagePlanePos1.
                                add((this.imagePlanePos2.sub(this.imagePlanePos1)).mul(widthProportion)).
                                add((this.imagePlanePos3.sub(this.imagePlanePos1)).mul(heightProportion));

                Vec3D rayDirection = pixel.sub(camera.getCameraPosition());
                Ray ray = new Ray(camera.getCameraPosition(), rayDirection.normalize(), 10000000.0f);

                // If an intersection exists between a ray and any give shape,
                // modify the color of the corresponding pixel on the image plane.
                //
                if (shape.geometry.intersect(ray)){
                    this.imagePlane.setRGB(x, y,
                            shape.appearance.material.getDiffuseColor().getRGB());
                }
            }
        }
    }


    void createImageFile(String fileName) throws  IOException{
        ImageIO.write(this.imagePlane, "png", new File(fileName));
    }


    void removeImageFile(String fileName) throws IOException {
        final String dir = System.getProperty("user.dir");
        final String path = dir + "/" + fileName;

        File file = new File(path);
        Files.deleteIfExists(file.toPath());
    }
}
