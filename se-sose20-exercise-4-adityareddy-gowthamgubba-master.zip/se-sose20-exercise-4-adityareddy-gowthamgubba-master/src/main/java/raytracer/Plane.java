package raytracer;

public class Plane extends Geometry {
    public final Vec3D planePoint, normal;

    public Plane(Vec3D planePoint, Vec3D normal) {
        this.planePoint = planePoint;
        this.normal = normal;
    }


    @Override
    String parameters() {
        return null;
    }


    /**
     * Evaluates ray-plane intersection returning true if an
     * intersection exists. Otherwise, returns false.
     * @param ray
     *          Ray projected from the origin.
     *
     * @see "https://en.wikipedia.org/wiki/Line%E2%80%93plane_intersection."
     */
    @Override
    boolean intersect(Ray ray) {
        // check if the ray is contained in the plane (case 1), or if there is no intersection (case 2)
        if (ray.getDirection().dot(this.normal) == 0.0) {
            if (this.planePoint.sub(ray.getOrigin()).dot(this.normal) == 0) {
                // If the ray lies on the plane (i.e., is contained by the plane)
                // the plane also intersects the ray at the origin and the closest
                // intersection point is thus the origin itself.
                return false; // in our specific case we ignore this
            } else {
                return false;
            }
        } else {
            return true;
        }
    }
}
