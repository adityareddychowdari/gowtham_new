package raytracer;

public class Transform {

    private final Vec3D scale, rotation, translation;

    /**
     * Constructs a Transform.
     * @param scale
     *          The scale transform.
     * @param rotation
     *          The rotation transform.
     * @param translation
     *          The translation transform.
     */
    public Transform(Vec3D scale, Vec3D rotation, Vec3D translation) {
        this.scale = scale;
        this.rotation  = rotation;
        this.translation = translation;
    }
}

