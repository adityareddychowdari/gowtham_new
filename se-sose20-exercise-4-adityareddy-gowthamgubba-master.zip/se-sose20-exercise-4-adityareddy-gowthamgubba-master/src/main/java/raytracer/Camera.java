package raytracer;

public class Camera{

    private final float viewDistance;
    private final Vec3D viewDirection;
    private final Vec3D cameraPosition;

    /**
     * Constructs a camera.
     *
     * @param viewDistance
     *          The distance between camera and viewing frame.
     * @param viewDirection
     *          The view direction.
     * @param cameraPosition
     *          The camera position.
     */
    public Camera(float viewDistance, Vec3D viewDirection, Vec3D cameraPosition) {
        this.viewDistance = viewDistance;
        this.viewDirection = viewDirection;
        this.cameraPosition = cameraPosition;
    }

    public float getViewDistance() {
        return viewDistance;
    }

    public Vec3D getCameraPosition() {
        return cameraPosition;
    }

    public Vec3D getViewDirection() {
        return viewDirection;
    }
}

