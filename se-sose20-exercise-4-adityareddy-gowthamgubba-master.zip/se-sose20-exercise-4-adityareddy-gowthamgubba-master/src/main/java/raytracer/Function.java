package raytracer;

/**
 * A quadratic function that solves for a
 * discriminant and intercept roots.
 */
public class Function {

    private final double T, T1, T2, discriminant;

    /**
     * Constructs and solves a quadratic function.
     *
     * @param a
     *        The a coefficient.
     * @param b
     *        The b coefficient.
     * @param c
     *       The c coefficient.
     */
    public Function(double a, double b, double c) {

        this.discriminant = (b * b) - (4 * a * c);
        double discSqrt = Math.sqrt(this.discriminant);

        this.T = (-1 * b) / 2.0 * a;
        this.T1 = ((-1 * b) - discSqrt) / 2.0 * a;
        this.T2 = ((-1 * b) + discSqrt) / 2.0 * a;
    }

    public double getT1() {
        return this.T1;
    }

    public double getDiscriminant() {
        return this.discriminant;
    }
}

