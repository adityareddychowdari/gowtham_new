package raytracer;

public class Group extends Transform {

    private final Vec3D scale = new Vec3D(1, 1, 1);
    private final Vec3D rotation = new Vec3D(0, 0 , 0);
    private final Vec3D translation = new Vec3D(0, 0 , 0);

    /**
     * Constructs a Group.
     * @param scale
     *          The scale transform.
     * @param rotation
     *          The rotation transform.
     * @param translation
     *          The translation transform.
     */
    public Group(Vec3D scale, Vec3D rotation, Vec3D translation) {
        super(scale, rotation, translation);
    }
}
