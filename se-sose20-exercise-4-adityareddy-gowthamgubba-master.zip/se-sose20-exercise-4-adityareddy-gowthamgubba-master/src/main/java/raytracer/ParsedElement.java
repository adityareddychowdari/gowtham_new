package raytracer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ParsedElement {
    String elementName;
    int transform_nestLevel;
    List<Map<String, String>> attributes = new ArrayList<>();

    public ParsedElement(int transform_nestLevel, String elementName, List<Map<String, String>> elementAttributes){
        this.elementName = elementName;
        this.transform_nestLevel = transform_nestLevel;
        this.attributes = elementAttributes;
    }


    @Override
    public String toString() {
        return  "\nTransform Nesting Level: " + this.transform_nestLevel +
                "\n           Element Name: " + this.elementName +
                "\n     Element Attributes: " + attributes;
    }
}
