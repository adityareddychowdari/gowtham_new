package raytracer;

public class Cone extends Geometry {

    private double radius, height;
    private Vec3D axis, vertex, center;

    /**
     * Constructs a cone.
     *
     * @param radius
     *          The radius of the circle at the base.
     * @param center
     *          The center point of the cone-base circumference.
     * @param vertex
     *          The tip/apex of the cone.
     */
    public Cone(double radius, Vec3D center, Vec3D vertex) {
        this.vertex = vertex;
        this.center = center;
        this.radius = radius;

        this.axis = this.vertex.sub(this.center);
        this.height = Math.abs(this.center.sub(this.vertex).getY());
    }

    @Override
    String parameters() {
        return null;
    }


    /**
     * Evaluates ray-sphere intersection returning true if an
     * intersection exists. Otherwise, returns false.
     *
     * @param ray
     *          Ray projected from the origin.
     *
     * @see "http://lousodrome.net/blog/light/2017/01/03/intersection-of-a-ray-and-a-cone/"
     */
    boolean intersect(Ray ray) {
        double adjacent = this.height;
        double opposite = this.radius;
        double hypotenuse = Math.sqrt((adjacent * adjacent) + (opposite * opposite));

        double cosTheta = adjacent/hypotenuse;
        double cos2Theta = cosTheta * cosTheta;

        Vec3D  O = ray.getOrigin();
        Vec3D  D = ray.getDirection().normalize();
        Vec3D  C = this.vertex;
        Vec3D  V = this.axis.normalize();
        Vec3D CO = O.sub(C);

        double a = (D.dot(V) * D.dot(V)) - cos2Theta;
        double b = 2 * ((D.dot(V) * CO.dot(V)) - (D.dot(CO) * cos2Theta));
        double c = (CO.dot(V) * CO.dot(V)) - (CO.dot(CO) * cos2Theta);

        Function function = new Function(a, b, c);

        double  d = function.getDiscriminant();
        double t1 = function.getT1();

        Vec3D  P = O.add(D.mul(t1));
        Vec3D CP = P.sub(C);
        double h = CP.len();

        /* case 1: the ray does not intersect the cone */
        if (d < 0.0) {
            return false;
        }

        /* case 2: the ray touches the cone at a single point */
        else if (d == 0.0) {
            return true;
        }

        if (t1 < 0.0) {
            return false;
        }

        // rejecting the shadow cone
        if (h < 0.0 || h > this.height) {
            return false;
        }

        /* case 3: the ray touches the cone two points*/
        return true;
    }
}

