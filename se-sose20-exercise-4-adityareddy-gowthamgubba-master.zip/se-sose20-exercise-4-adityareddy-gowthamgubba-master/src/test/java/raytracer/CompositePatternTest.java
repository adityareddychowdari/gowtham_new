package raytracer;

import org.junit.Test;

import java.lang.reflect.Method;

import static org.junit.Assert.assertTrue;

public class CompositePatternTest {
    @Test
    public void methodTest() throws Exception {
        final Object StackedTransform = new StackedTransform(new Vec3D(1.0, 1.0, 1.0),
                new Vec3D(0.0, 0.0, 0.0),
                new Vec3D(0.0, 0.0, 0.0));

        final Object Transform = new StackedTransform(new Vec3D(1.0, 1.0, 1.0),
                new Vec3D(0.0, 0.0, 0.0),
                new Vec3D(0.0, 0.0, 0.0));

        assertTrue(StackedTransform instanceof ITransform);
        assertTrue(Transform instanceof ITransform);

        // if expected method does not exist, thrown Exception will cause test to fail
        Method getTranslation = ITransform.class.getDeclaredMethod("getTranslation");
        Method addTransform = ITransform.class.getDeclaredMethod("addTransform", Transform.class);
    }
}
