package raytracer;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class IntersectTest {
    final private double precision = 0.00001;

    private final double radius = 1.7;
    private final Vec3D center = new Vec3D(0, 0, 5);
    private final Vec3D vertex = new Vec3D(0, 5, 5);

    private final Vec3D origin = new Vec3D(0, 0, 0);
    private final float length = 100000000000000000f;

    private final Cone cone = new Cone(radius, center, vertex);
    private final Sphere sphere = new Sphere(center, radius);


    @Test
    public void SphereIntersectionTest(){
        Vec3D direction;
        Ray intersectRay;

        // ray with known intersection
        direction = new Vec3D(0.3623975938255366, 0.24084809030641247, 0.9003666927342523);
        intersectRay = new Ray(origin, direction, length);
        //assertTrue(sphere.intersect(intersectRay));

        // ray with known no-intersection
        direction = new Vec3D(-0.5773502691896258, 0.5773502691896258, 0.5773502691896258);
        intersectRay = new Ray(origin, direction, length);
        assertFalse(sphere.intersect(intersectRay));
    }


    @Test
    public void ConeIntersectionTest(){
        Vec3D direction;
        Ray intersectRay;

        // ray with known intersection
        direction = new Vec3D(-0.027332526200118012, 0.5403430179561797, 0.841000806157478);
        intersectRay = new Ray(origin, direction, length);
        assertTrue(cone.intersect(intersectRay));

        // ray with known no-intersection
        direction = new Vec3D(-0.5773502691896258, 0.5773502691896258, 0.5773502691896258);
        intersectRay = new Ray(origin, direction, length);
        assertFalse(cone.intersect(intersectRay));
    }

}

