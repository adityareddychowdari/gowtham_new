package raytracer;

import org.junit.Test;

import java.lang.reflect.Method;

public class AbstractPatternTest {
    /*
     * If expected methods do not exist,
     * an exception will be thrown to causing the test to fail!
     */
    @Test
    public void createSphereMemberTest() throws Exception {
        Method createSphere = raytracer.ShapeFactory.class.getDeclaredMethod("createSphere", ParsedElement.class);
    }

    @Test
    public void createConeMemberTest() throws Exception {
        Method createCone = raytracer.ShapeFactory.class.getDeclaredMethod("createCone", ParsedElement.class);
    }
}
