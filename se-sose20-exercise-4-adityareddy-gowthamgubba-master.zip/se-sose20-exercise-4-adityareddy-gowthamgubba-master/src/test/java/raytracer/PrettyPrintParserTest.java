package raytracer;

import org.junit.Test;

import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import java.lang.reflect.Method;

public class PrettyPrintParserTest {
    /*
     * If expected methods do not exist,
     * an exception will be thrown to causing the test to fail!
     */
    @Test
    public void enterMemberTest() throws Exception {
        Method enter = raytracer.PrettyPrintParser.class.getDeclaredMethod("enter", StartElement.class);
    }

    @Test
    public void exitMemberTest() throws Exception {
        Method exit = PrettyPrintParser.class.getDeclaredMethod("exit", EndElement.class);
    }
}
