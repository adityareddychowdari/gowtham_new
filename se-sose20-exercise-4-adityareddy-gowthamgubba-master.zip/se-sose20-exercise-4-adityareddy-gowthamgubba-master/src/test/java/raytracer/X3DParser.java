package raytracer;

import org.junit.Test;

import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import java.lang.reflect.Method;

import static org.junit.Assert.assertTrue;

public class X3DParser {
        @Test
        public void methodTest() throws Exception {
            final Object X3DParser = new XMLParser("./resources/scene.x3d");
            assertTrue(X3DParser instanceof XMLParser);

            // if expected method does not exist, thrown Exception will cause test to fail
            Method parseMethod = XMLParser.class.getDeclaredMethod("parse");
            Method enterMethod = XMLParser.class.getDeclaredMethod("enter", StartElement.class);
            Method exitMethod = XMLParser.class.getDeclaredMethod("exit", EndElement.class);
        }
}
