package raytracer;

import org.junit.Test;
import javax.xml.stream.XMLStreamException;
import java.io.FileNotFoundException;

public class X3DTest {

    @Test
    public void creatableTest() throws FileNotFoundException, XMLStreamException {
        //X3D x3d = new X3D("./resources/scene.x3d");
    }
}
