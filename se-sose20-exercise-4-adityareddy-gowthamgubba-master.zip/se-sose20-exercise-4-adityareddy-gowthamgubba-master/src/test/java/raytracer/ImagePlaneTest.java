package raytracer;

import org.junit.Test;
import java.lang.reflect.Method;

public class ImagePlaneTest {
    final int imageWidth = 800;
    final int imageHeight = 800;

    final float viewDistance = 1.0f;
    final Vec3D origin = new Vec3D(0, 0, 0);
    final Vec3D viewDirection = new Vec3D(0, 0, 1);
    final Camera camera = new Camera(viewDistance, viewDirection, origin);
    final ImagePlane imagePlane = new ImagePlane(imageWidth, imageHeight, camera);

    /*
     * If expected methods do not exist,
     * an exception will be thrown to causing the test to fail!
     */
    @Test
    public void enterMemberTest() throws Exception {
        Method trace = raytracer.ImagePlane.class.getDeclaredMethod("trace", Shape.class);
    }
}
