package raytracer;

import org.junit.Test;
import java.lang.reflect.Method;

public class SceneTest {
    /*
     * If expected methods do not exist,
     * an exception will be thrown to causing the test to fail!
     */
    @Test
    public void enterMemberTest() throws Exception {
        Method getGeometry = raytracer.Scene.class.getDeclaredMethod("getShape");
    }
}
