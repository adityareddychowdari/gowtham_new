package raytracer;

import org.junit.Test;

import java.lang.reflect.Method;

public class TraceTest {
    /*
     * If expected methods do not exist,
     * an exception will be thrown to causing the test to fail!
     */
    @Test
    public void traceMemberTest() throws Exception {
        Method trace = raytracer.ImagePlane.class.getDeclaredMethod("trace", Shape.class);
    }
}
