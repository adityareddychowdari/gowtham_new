package exercise;

import org.junit.Test;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;

public class GroupTest {

    @Test
    public void GroupConstructorTest() {
        Group group = new Group(new Vec3D(1, 1, 0));
        assertEquals(group.scale.toString(), new Vec3D(1, 1, 1).toString());
        assertEquals(group.translation.toString(), new Vec3D(0, 0, 0).toString());
    }

    @Test
    public void GroupInheritanceTest() {
        Transform group = new Group(new Vec3D(1, 1, 0));
        assertTrue(group instanceof Transform);
    }
}
