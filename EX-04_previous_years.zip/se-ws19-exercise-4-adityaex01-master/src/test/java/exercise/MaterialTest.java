package exercise;

import org.junit.Test;

public class MaterialTest {

    @Test
    public void MaterialConstructorTest() {
       //  Material material = new Material(new Vec3D(1, 2, 3));
       //  assertEquals(material.diffuseColor, new Vec3D(1, 2, 3));
    }
}
