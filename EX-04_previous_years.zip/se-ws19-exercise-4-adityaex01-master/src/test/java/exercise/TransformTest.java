package exercise;

import org.junit.Test;

public class TransformTest {

    @Test
    public void TransformConstructorTest() {
//        Vec3D scale = new Vec3D(1, 0, 0);
//        Vec3D translation = new Vec3D(0, 0, 1);
//        Transform transform = new Transform(scale, translation);
//        assertEquals(transform.scale, new Vec3D(1, 0, 0));
//        assertEquals(transform.translation, new Vec3D(0, 0, 1));
    }
}
