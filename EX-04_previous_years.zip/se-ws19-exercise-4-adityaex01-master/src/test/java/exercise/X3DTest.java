package exercise;

import org.junit.Test;

import javax.xml.stream.XMLStreamException;
import java.io.FileNotFoundException;

import static org.junit.Assert.assertFalse;

public class X3DTest {
    final static String RESOURCE_PATH = "src/test/resources/";

    /* Test if the constructor loads the X3D file correctly. */
    @Test
    public void X3dFileConstructorTest() throws FileNotFoundException, XMLStreamException {
        X3D x3d = new X3D(RESOURCE_PATH + "test4.x3d");

        assertFalse(x3d.shapes.isEmpty());
        assertFalse(x3d.transforms.isEmpty());
    }
}
