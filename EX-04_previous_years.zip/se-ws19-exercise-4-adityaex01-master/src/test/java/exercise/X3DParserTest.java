package exercise;

import org.junit.Test;

import javax.xml.stream.XMLStreamException;
import java.io.FileNotFoundException;

import static org.junit.Assert.*;


public class X3DParserTest {


    @Test
    public void ParserTest() throws FileNotFoundException, XMLStreamException {
        X3DParser parser = new X3DParser("./src/test/resources/test4.x3d");

        parser.parse();
        assertFalse(parser.getShapes().isEmpty());
        assertFalse(parser.getTransforms().isEmpty());
    }
}
