package exercise;

import java.io.IOException;
import java.util.concurrent.Callable;

public class ImageBuilder implements Callable<ImageBuilder> {
	private Image image;
	private int[] build;
	private int width, height;
	private int x_offset, y_offset;


	public ImageBuilder(Image image, int x_offset, int y_offset, int width, int height) {
		super();
		this.image = image;
		this.width = width;
		this.height = height;
		this.x_offset = x_offset;
		this.y_offset = y_offset;

	}


	public int getX_offset() {
		return x_offset;
	}


	public int getY_offset() {
		return y_offset;
	}


	public int getWidth() {
		return width;
	}


	public int getHeight() {
		return height;
	}


	public int[] getBuild() {
		return build;
	}


	@Override
	public ImageBuilder call() {
		build = new int[ width * height];
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				build[y * width + x] = image.trace(x + x_offset, y + y_offset);
			}
		}
		return this;
	}}
