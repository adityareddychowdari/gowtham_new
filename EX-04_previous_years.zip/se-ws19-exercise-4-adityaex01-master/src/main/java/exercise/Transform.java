package exercise;

public abstract class Transform {

    public Vec3D scale;
    public Vec3D translation;
    public Vec3D x3dTranslation;
	public Transform parent;

    public Transform(Vec3D x3dTranslation) {
        this.x3dTranslation = x3dTranslation;
    }
    public void addChild(final Transform t){;}

    public void removeChild(final Transform t){;}

    public void addShape(final Shape s){;}

    public void removeShape(final Shape s){;}

    public void translate(){;}

    public void translate(final Vec3D parent_t){;
    }
}



