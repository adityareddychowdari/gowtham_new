package exercise;

import java.util.List;
import java.util.*;

public class Group extends Transform {

    public final Vec3D scale = new Vec3D(1, 1, 1);
    public final Vec3D translation = new Vec3D(0, 0, 0);
    public Vec3D x3dTranslation;

    private List<Transform> transforms;
    private List<Shape> shapes;



    public Group(final Vec3D x3dTranslation) {
        super(x3dTranslation);
        this.transforms = new ArrayList<Transform>();
        this.shapes = new ArrayList<Shape>();
    }

    public void addChild(final Transform t){
        transforms.add(t);
    }

    public void removeChild(final Transform t){
        transforms.remove(t);
    }

    public void addShape(final Shape s){
        shapes.add(s);
    }

    public void removeShape(final Shape s){
        shapes.remove(s);
    }

    public void translate(){
        this.translate(new Vec3D( 0, 0, 0));
    }

    public void translate(final Vec3D parent_t){
        Vec3D WorldTransform = this.translation.add(parent_t);

        for (Transform t : this.transforms){
            System.out.println(t);
            t.translate(WorldTransform);
        }

        for (Shape s: this.shapes){
            s.translate(WorldTransform);
        }
    }
}
