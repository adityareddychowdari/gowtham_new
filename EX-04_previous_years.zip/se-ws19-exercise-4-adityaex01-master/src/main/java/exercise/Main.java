package exercise;

import javax.xml.stream.XMLStreamException;
import java.io.IOException;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException, XMLStreamException {

        // creating an object representation of an .x3d file in memory
        X3D x3d = new X3D("./src/test/resources/test4.x3d");


        // accessing the list of all x3d shapes and transforms specified in the .x3d file
        List<Shape> shapes = x3d.shapes;
        List<Transform> transforms = x3d.transforms;


        final int width = 1000;
        final int height = 1000;
        final double viewingDistance = 3.0;

        /* Image represents the image plane, i.e., the plane where shapes are traced onto
         * by the ray tracer. Here, we create the image plane and cast light onto it.
         */
        Image image = new Image(width, height, viewingDistance);
        image.lights.add(new Light(new Vec3D(500, 500, 10), 0.5));

        // ... ray-tracing on all geometry from the .x3d file
        for (Shape shape: shapes){
            //todo: all shapes including planes and cones !!!!
            if(shape.getGeometry() instanceof Sphere){
                image.shapes.add(shape);
            }
        }

        image.writeImage("image-plane.png");
    }
}
