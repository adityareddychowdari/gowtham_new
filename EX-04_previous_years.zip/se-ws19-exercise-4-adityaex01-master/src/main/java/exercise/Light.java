package exercise;

public class Light {
	private Vec3D position;
	private double intensity;


	public Light(Vec3D position,double intensity) {
		this.position = position;
		this.intensity = intensity;
	}


	public double getIntensity() {
		return intensity;
	}


	public double lambert(Ray surfaceNormal) {
	    // lambert is the emission or reflection of one lumen per square centimetre
		Vec3D lightVector = position.sub(surfaceNormal.getPosition());

		double cosAlpha = surfaceNormal.getDirection().normalize().dot(lightVector.normalize());
		if(cosAlpha < 0) {
			return 0;
		}
		return cosAlpha;
	}
}
