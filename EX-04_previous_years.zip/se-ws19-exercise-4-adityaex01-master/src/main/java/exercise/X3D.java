package exercise;

import javax.xml.stream.XMLStreamException;
import java.io.FileNotFoundException;
import java.util.List;

public class X3D {

    public List<Shape> shapes;
    public List<Transform> transforms;
    public Transform main_Transform;

    public X3D(String filePath) throws FileNotFoundException, XMLStreamException {
        X3DParser parser = new X3DParser(filePath);

        parser.parse();
        this.shapes = parser.getShapes();
        this.main_Transform = parser.getMainTransforms();
        this.transforms = parser.getTransforms();
    }
}
