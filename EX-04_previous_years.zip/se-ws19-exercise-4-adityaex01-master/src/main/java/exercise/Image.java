package exercise;

import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;

class Image {
	private Camera camera;
	private int width, height;
	private double viewingDistance;

	List<Shape> shapes = new ArrayList<>();
	List<Light> lights = new ArrayList<>();


	Image(int width, int height, double viewingDistance) {
		this.width = width;
		this.height = height;

		camera =  new Camera(1000);
		this.viewingDistance = viewingDistance;
	}


	/**
	 * The ray function returns a ray vector. The ray starts from
	 * the origin and goes through each and every pixel (x, y) of
	 * the image plane.
	 *
	 * @param x x position of the pixel
	 * @param y y position of the pixel
	 */
	private Ray ray(int x, int y) {
		Vec3D position = new Vec3D(x,y,0);
		Vec3D origin = new Vec3D(height/2/ viewingDistance,width/2/ viewingDistance, - camera.distance);
		return new Ray(position, position.sub(origin));
	}


	/**
	 * The trace function traces a shape onto the image plane.
	 * For each ray that passes through an image plane pixel,
	 * if an intersection between the ray and geometry exists,
	 * the corresponding pixel is traced.
	 *
	 * @param x x position of the pixel
	 * @param y y position of the pixel
	 */
	int trace(int x, int y){
		Shape closestShape = null;
		Ray closestRayIntersect = null;

		Ray ray = ray((int) (x/ viewingDistance), (int) (y/ viewingDistance));

		for (Shape shape : shapes) {
			Ray intersect = shape.getGeometry().intersect(ray);
			if(intersect != null) {
				if(closestRayIntersect == null ||
						closestRayIntersect.getPosition().getZ() > intersect.getPosition().getZ()) {
					closestShape = shape;
					closestRayIntersect = intersect;
				}
			}
		}

		if(closestShape == null) return Color.BLACK.getRGB();

		double lightFactor = lightFactor(closestRayIntersect);
		Color color = new Color(
				Math.min((int) (closestShape.getAppearance().material.color.getBlue() * lightFactor),255),
				Math.min((int) (closestShape.getAppearance().material.color.getGreen() * lightFactor),255),
				Math.min((int) (closestShape.getAppearance().material.color.getBlue() * lightFactor),255)
		);
		return  color.getRGB();
	}


	/**
	 *  The function writeImage writes out the image plane
	 *  as a png file.
	 *
	 * @param filename File name of the image with file extension
	 *                    (i.e. you have to specify file type)
	 */
	void writeImage(String filename) throws IOException {
		File file = new File(filename);
		BufferedImage bufferedImage = threadedImageBuilder();
		ImageIO.write(bufferedImage, "png", file);
	}


	// thread management
	BufferedImage threadedImageBuilder() {
		ForkJoinPool mainPool = new ForkJoinPool();

		int xChunk = width/mainPool.getParallelism() + 1;
		int yChunk = height/mainPool.getParallelism() + 1;

		BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		List<ImageBuilder> builders =
				new ArrayList<>(mainPool.getParallelism() * mainPool.getParallelism());

		for (int y = 0; y <= height; y+= yChunk) {
			for (int x = 0; x <= width; x+= xChunk) {
				builders.add(new ImageBuilder(this, x, y,Math.min(xChunk,width - x),
						Math.min(yChunk,height - y)));
			}
		}


		List<Future<ImageBuilder>> answers = mainPool.invokeAll(builders);
		for (Future<ImageBuilder> answer : answers) {
			ImageBuilder imageBuilder;
			try {
				imageBuilder = answer.get();
				bufferedImage.setRGB(imageBuilder.getX_offset(), imageBuilder.getY_offset(),
						imageBuilder.getWidth(), imageBuilder.getHeight(), imageBuilder.getBuild(),
						0, imageBuilder.getWidth());
			} catch (InterruptedException | ExecutionException e) {
				e.printStackTrace();
			}
		}
		return bufferedImage;
	}


	// lighting
	private double lightFactor(Ray surfaceNormal) {
		double lightFactor = 0.5;
		for(Light l: lights) {
			lightFactor += l.lambert(surfaceNormal) * l.getIntensity();
		}
		return lightFactor;
	}
}
