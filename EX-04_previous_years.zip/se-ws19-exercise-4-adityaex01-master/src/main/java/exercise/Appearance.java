package exercise;

public class Appearance{

    public Material material;

    public Appearance(Material material) {
        this.material = material;
    }
    public Vec3D getdiffuseColor() {
		return material.getdiffuseColor();
	}
}


