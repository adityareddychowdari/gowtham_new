package exercise;

public abstract class Geometry {

    public abstract Ray intersect(Ray ray);

    public void translate(final Vec3D t) {
	}
}
