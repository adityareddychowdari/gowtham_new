package exercise;

public class Shape {
	private Geometry geometry;
	private Appearance appearance;

	public Shape(Geometry geometry, Appearance appearance) {
	    this.geometry = geometry;
	    this.appearance = appearance;
	}


	public Geometry getGeometry() {
		return geometry;
	}


	public Appearance getAppearance() {
		return appearance;
	}
	public Vec3D getdiffuseColor() {
		return appearance.getdiffuseColor();
	}

	public void translate(final Vec3D t) {
		geometry.translate(t);
	}
}


