package exercise;

import java.awt.*;
import java.util.Random;

public class Material{

    public Vec3D diffuseColor;
    public Color color;

    public Material(Vec3D diffuseColor){
        this.diffuseColor = diffuseColor;

        // temp implementation to generate a random color
        Random random = new Random();
        this.color = new Color(random.nextInt(256),random.nextInt(256),random.nextInt(256));
    }
        public Vec3D getdiffuseColor() {
    		return diffuseColor;
    	}
    }
