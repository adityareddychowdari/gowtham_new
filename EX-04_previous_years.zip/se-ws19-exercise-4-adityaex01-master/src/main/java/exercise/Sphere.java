package exercise;


public class Sphere extends Geometry {
	public  Vec3D position;
	public  double radius;

	public Sphere(Vec3D position, double radius) {
		this.position = position;
		this.radius = radius;
	}


	@Override
	public Ray intersect(Ray ray) {
		// http://wiki.cgsociety.org/index.php/Ray_Sphere_Intersection

		Vec3D rayPosition = ray.getPosition();
		Vec3D rayDirection = ray.getDirection();
		Vec3D center = position;

		double A =  rayDirection.dot(rayDirection);
		double B = rayPosition.sub(center).mul(2).dot(rayDirection);
		double C = rayPosition.sub(center).dot(rayPosition.sub(center)) - radius * radius;
		double root = B * B - 4 * A * C;

		// evaluating the root ...
		if(root < 0){
			return null; // no real roots
		}

		root = Math.sqrt(root);
		double t1 = (-1 * B - root)/2.0/A;
		double t2 = (-1 * B + root)/2.0/A;

		if(Double.isNaN(t1) && Double.isNaN(t2)){
			return null;
		}

		double tMin = Math.min(t1, t2);

		if(Double.isNaN(tMin)){
			if(Double.isNaN(t1)){
				tMin = t2;
			}
			else{
				tMin = t1;
			}
		}

		if(tMin < 0) {
			return null;
		}

		Vec3D intersectPosition = ray.getDirection().mul(tMin).add(ray.getPosition());
		Vec3D intersectNormal = intersectPosition.sub(position);
		return new Ray(intersectPosition,intersectNormal);
	}
	@Override
    public void translate(final Vec3D t) {
        this.position.add(t);
	}
}



