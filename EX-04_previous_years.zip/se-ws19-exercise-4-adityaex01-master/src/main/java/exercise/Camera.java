package exercise;

class Camera {
     double distance;

    Camera(double distance) {
        this.distance = distance;
    }
}
