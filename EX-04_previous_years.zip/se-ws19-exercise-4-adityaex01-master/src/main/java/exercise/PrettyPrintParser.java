package exercise;

import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

/**
 * PrettyPrintParser extends XMLParser, overriding
 * the enter and exit functions to prefix all
 * opening tags with ⟶ and all closing tags
 * with ⟵ .
 */
public class PrettyPrintParser extends XMLParser{
    private int indentLevel = 0;


    public PrettyPrintParser(String filePath) {
        super(filePath);
    }


    @Override
    public void enter(StartElement element){
        if(indentLevel == 0){
            System.out.print("\u2192  ");
            System.out.print(element.getName().toString());
            indentLevel  = indentLevel + 4;
        }
        else {
            for(int count = 0; count < indentLevel; count++){
                System.out.print(" ");
            }
            System.out.print("\u2192  ");
            System.out.print(element.getName().toString());
            indentLevel  = indentLevel + 4;
        }
    }


    @Override
    public void exit(EndElement element){
        if(indentLevel != 0){
            indentLevel  = indentLevel - 4;
            for(int count = 0; count < indentLevel; count++){
                System.out.print(" ");
            }
            System.out.print("\u2190  ");
            System.out.print(element.getName().toString());
        }
        else {
            System.out.print("\u2190  ");
            System.out.print(element.getName().toString());
        }
    }
}

