package exercise;

import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;

import java.util.*;
import java.util.List;

/**
 * The X3DParser parses X3D files
 */
public class X3DParser extends XMLParser {

    // x3d data containers
    private List <Shape> shapes;
    private List <Transform> transforms;
    private Transform main_Transforms;
    private Transform pivot;

    // binary flags to signal tag-based execution
    private boolean coneFlagRaised;
    private boolean sphereFlagRaised;
    private boolean groupFlagRaised;
    private boolean shapeFlagRaised;
    private boolean transformFlagRaised;

    // x3d shape-parameters
    private Vec3D apex;
    private Vec3D axis;
    private Vec3D center;
    private double radius;
    private double height;
    private Vec3D diffuseColor;

    // x3d shape-parameter defaults
    private final Vec3D DEFAULT_APEX = new Vec3D(0, 0, 0);
    private final Vec3D DEFAULT_AXIS = new Vec3D(0, 0, 0);
    private final Vec3D DEFAULT_CENTER = new Vec3D(0, 0, 0);
    private final double DEFAULT_RADIUS = 1.0;
    private final double DEFAULT_HEIGHT = 4.0;
    private final Vec3D DEFAULT_DIFFUSECOLOR = new Vec3D(1, 0, 1);

    // x3d shape-transform
    private Transform transform;

    // x3d default shape-transform
    private Transform DEFAULT_TRANSFORM = new Group(new Vec3D(0, 0, 0));

    public X3DParser(String filePath) {
        super(filePath);
        this.shapes = new ArrayList<Shape>();
        this.transforms = new ArrayList<Transform>();

        this.shapeFlagRaised = false;
        this.transformFlagRaised = false;

        this.coneFlagRaised = false;
        this.sphereFlagRaised = false;

        this.radius = 50.0;
        this.height = 0.0;
        this.apex = null;
        this.axis = null;
        this.center = new Vec3D(190, 200, 50);
        this.transform = null;
        this.diffuseColor = null;

        this.main_Transforms = new Group(new Vec3D(0, 0, 0));
        this.pivot = this.main_Transforms;
    }


    @Override
    public void enter(StartElement element){
        Iterator<Attribute> iterator = element.getAttributes();

        // ... for every shape, raise a flag to indicate tag contains shape parameters
        if(element.getName().toString().equals("Shape")){
            this.shapeFlagRaised = true;
        }
        checkShape(element, iterator);

        // using screen node tree method to add Transformation node
        // ... for every transform, raise a flag to indicate tag contains translation parameters
        if(element.getName().toString().equals("Transform")){
                this.transformFlagRaised = true;
                checkTransform(element, iterator);
                this.pivot.addChild(this.transform); 
                this.transform.parent = this.pivot;
                this.pivot = this.transform;
            }
    }


    @Override
    public void exit(EndElement element) {

        if (element.getName().toString().equals("Transform")) {
            transforms.add(this.transform);
            this.pivot = this.transform.parent;
            this.transformFlagRaised = false;
        }

        if (element.getName().toString().equals("Shape")) {
            final Shape s = createShape();
            this.shapes.add(s);
            this.transform.addShape(s);
            this.shapeFlagRaised = false;
            this.coneFlagRaised = false;
            this.sphereFlagRaised = false;
            // todo: implement an explicit method for specifying defaults
            // reset the value to default:
            this.radius = this.DEFAULT_RADIUS;
            this.height = this.DEFAULT_HEIGHT;
            this.apex = this.DEFAULT_APEX;
            this.axis = this.DEFAULT_AXIS;
            this.center = this.DEFAULT_CENTER;
            this.diffuseColor = this.DEFAULT_DIFFUSECOLOR;

        }
    }


    private void checkTransform(StartElement element, Iterator<Attribute> iterator){
        if (this.transformFlagRaised) {
            while (iterator.hasNext()) {
                Attribute attribute = iterator.next();
                if (attribute.getName().getLocalPart().equals("translation")){
                    Vec3D x3dTranslation = toVec3D(attribute.getValue());
                    this.transform = new Group(x3dTranslation);
                }
            }
        }
    }


    private void checkShape(StartElement element, Iterator<Attribute> iterator){
        // ... x3d tags of interest
        List<String> x3dShapeParameters = Arrays.asList("Shape", "Transform", "Sphere", "Cone", "Material");

        if(x3dShapeParameters.contains(element.getName().toString())) {

            // updating binary flags for execution control
            if (this.shapeFlagRaised) {
                switch (element.getName().toString()) {
                    case "Sphere":
                        this.sphereFlagRaised = true;
                        break;
                    case "Cone":
                        this.coneFlagRaised = true;
                        break;
                }
            }

            //  ... for every sphere, get the x3d parameters if any
            // parameters are not specified, default to constructor defaults
            if (this.sphereFlagRaised) {

                while (iterator.hasNext()) {
                    Attribute attribute = iterator.next();

                    switch (attribute.getName().getLocalPart()) {
                        case "radius":
                            this.radius = Double.parseDouble(attribute.getValue());
                            break;
                        case "center":
                            this.center = toVec3D(attribute.getValue());
                            break;
                        case "diffuseColor":
                            this.diffuseColor = toVec3D(attribute.getValue());
                            break;
                    }
                }

            }

            //  ... for every cone, get the x3d parameters if any
            // parameters are not specified, default to constructor defaults
            if (this.coneFlagRaised) {
                while (iterator.hasNext()) {
                    Attribute attribute = iterator.next();
                    switch (attribute.getName().getLocalPart()) {
                        case "radius":
                            this.radius = (Double.parseDouble(attribute.getValue()));
                            break;
                        case "height":
                            this.height = (Double.parseDouble(attribute.getValue()));
                            break;
                        case "diffuseColor":
                            this.diffuseColor = toVec3D(attribute.getValue());
                            break;
                    }
                }
            }
        }

    }


    private Vec3D toVec3D(String vec){
        String[] strValues = vec.split("\\s+");
        return new Vec3D(Double.parseDouble(strValues[0]),
                Double.parseDouble(strValues[1]), Double.parseDouble(strValues[2]));
    }


    private Shape createShape(){

        if(coneFlagRaised){
            //Geometry geometry = new Cone(this.apex, this.radius, this. height);
            Geometry geometry = new Cone(this.apex, this.axis, this.radius, this. height);
            Material material = new Material(this.diffuseColor);
            Appearance appearance = new Appearance(material);
            return new Shape(geometry, appearance);
        }

        else if (sphereFlagRaised){
            Geometry geometry = new Sphere(this.center, this.radius);
            Material material = new Material(this.diffuseColor);
            Appearance appearance = new Appearance(material);
            return new Shape(geometry, appearance);
        }
        return null;
    }


    public List<Shape> getShapes(){
        return this.shapes;
    }


    public Transform getMainTransforms(){
        return this.main_Transforms;
    }

    public List<Transform> getTransforms(){
        return this.transforms;
    }
}
