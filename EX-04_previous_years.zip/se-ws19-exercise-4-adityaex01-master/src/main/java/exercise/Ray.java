package exercise;

public class Ray {
    private Vec3D position;
    private Vec3D direction;

    Ray(Vec3D position, Vec3D direction) {
        this.position = position;
        this.direction = direction;
    }


    public Vec3D getDirection() {
        return direction;
    }


    public Vec3D getPosition() {
        return position;
    }
}
